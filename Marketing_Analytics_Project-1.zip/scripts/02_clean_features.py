import pandas as pd
import numpy as np
from datetime import datetime

df = pd.read_csv("/home/claude/project/data/marketing_campaign.csv", sep="\t")

# --- Cleaning ---
# 1. Drop rows with missing Income (24 rows, ~1%)
df = df.dropna(subset=["Income"]).copy()

# 2. Remove income outlier(s) — cap at 99th percentile logic / drop absurd value
df = df[df["Income"] < 200000].copy()

# 3. Fix age: derive from Year_Birth, drop unrealistic birth years (before 1930 -> age > 96)
df["Age"] = 2015 - df["Year_Birth"]  # dataset collected ~2014-2015 (Dt_Customer max year)
df = df[df["Age"] <= 90].copy()

# 4. Normalize Marital_Status: merge Alone/Absurd/YOLO into cleaner categories
df["Marital_Status"] = df["Marital_Status"].replace({
    "Alone": "Single", "Absurd": "Single", "YOLO": "Single"
})

# 5. Parse Dt_Customer -> tenure in days as of last date in dataset
df["Dt_Customer"] = pd.to_datetime(df["Dt_Customer"], format="%d-%m-%Y")
max_date = df["Dt_Customer"].max()
df["Customer_Tenure_Days"] = (max_date - df["Dt_Customer"]).dt.days

# 6. Feature engineering
spend_cols = ["MntWines","MntFruits","MntMeatProducts","MntFishProducts","MntSweetProducts","MntGoldProds"]
df["Total_Spend"] = df[spend_cols].sum(axis=1)
df["Total_Children"] = df["Kidhome"] + df["Teenhome"]
df["Total_Purchases"] = df["NumDealsPurchases"] + df["NumWebPurchases"] + df["NumCatalogPurchases"] + df["NumStorePurchases"]
df["Total_Campaigns_Accepted"] = df[["AcceptedCmp1","AcceptedCmp2","AcceptedCmp3","AcceptedCmp4","AcceptedCmp5","Response"]].sum(axis=1)

# Age groups
df["Age_Group"] = pd.cut(df["Age"], bins=[17,29,39,49,59,100], labels=["18-29","30-39","40-49","50-59","60+"])

# Income groups (quartiles)
df["Income_Segment"] = pd.qcut(df["Income"], 4, labels=["Low","Mid-Low","Mid-High","High"])

print("Final shape after cleaning:", df.shape)
print("\nColumns added:", ["Age","Customer_Tenure_Days","Total_Spend","Total_Children","Total_Purchases","Total_Campaigns_Accepted","Age_Group","Income_Segment"])
print("\nSanity check - Age describe:\n", df["Age"].describe())
print("\nMarital status after cleanup:", df["Marital_Status"].unique())

df.to_csv("/home/claude/project/data/marketing_campaign_cleaned.csv", index=False)
print("\nSaved cleaned dataset.")

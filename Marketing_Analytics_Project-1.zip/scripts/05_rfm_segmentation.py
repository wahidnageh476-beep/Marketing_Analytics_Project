import pandas as pd

df = pd.read_csv("/home/claude/project/data/marketing_campaign_cleaned.csv")

# RFM: Recency (already have, lower=better), Frequency (Total_Purchases), Monetary (Total_Spend)
df["R_Score"] = pd.qcut(df["Recency"], 4, labels=[4,3,2,1]).astype(int)   # lower recency = higher score
df["F_Score"] = pd.qcut(df["Total_Purchases"].rank(method="first"), 4, labels=[1,2,3,4]).astype(int)
df["M_Score"] = pd.qcut(df["Total_Spend"].rank(method="first"), 4, labels=[1,2,3,4]).astype(int)
df["RFM_Score"] = df["R_Score"] + df["F_Score"] + df["M_Score"]

def segment(row):
    if row["RFM_Score"] >= 10:
        return "Champions"
    elif row["RFM_Score"] >= 8:
        return "Loyal Customers"
    elif row["RFM_Score"] >= 6:
        return "Potential Loyalists"
    elif row["RFM_Score"] >= 4:
        return "At Risk"
    else:
        return "Hibernating"

df["Segment"] = df.apply(segment, axis=1)

print("=== SEGMENT DISTRIBUTION ===")
print(df["Segment"].value_counts())

print("\n=== SEGMENT PROFILE ===")
print(df.groupby("Segment").agg(
    Count=("ID","count"),
    Avg_Income=("Income","mean"),
    Avg_Spend=("Total_Spend","mean"),
    Avg_Recency=("Recency","mean"),
    Response_Rate=("Response","mean")
).sort_values("Avg_Spend", ascending=False))

df.to_csv("/home/claude/project/data/marketing_campaign_with_segments.csv", index=False)
print("\nSaved segmented dataset.")

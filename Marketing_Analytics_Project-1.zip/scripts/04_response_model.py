import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
from sklearn.linear_model import LogisticRegression

df = pd.read_csv("/home/claude/project/data/marketing_campaign_cleaned.csv")

le_edu = LabelEncoder()
le_mar = LabelEncoder()
df["Education_enc"] = le_edu.fit_transform(df["Education"])
df["Marital_enc"] = le_mar.fit_transform(df["Marital_Status"])

features = ["Age","Income","Kidhome","Teenhome","Recency","Total_Spend","Total_Purchases",
            "NumWebVisitsMonth","Customer_Tenure_Days","Education_enc","Marital_enc",
            "NumDealsPurchases","NumWebPurchases","NumCatalogPurchases","NumStorePurchases"]

X = df[features]
y = df["Response"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

baseline_acc = max(y_test.mean(), 1 - y_test.mean())
print(f"Baseline (majority class) accuracy: {baseline_acc:.3f}")

lr = LogisticRegression(max_iter=2000)
lr.fit(X_train, y_train)
print(f"\nLogistic Regression Accuracy: {accuracy_score(y_test, lr.predict(X_test)):.3f}")
print(f"Logistic Regression ROC-AUC: {roc_auc_score(y_test, lr.predict_proba(X_test)[:,1]):.3f}")

rf = RandomForestClassifier(n_estimators=300, max_depth=6, random_state=42, class_weight="balanced")
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)
print(f"\nRandom Forest Accuracy: {accuracy_score(y_test, rf_pred):.3f}")
print(f"Random Forest ROC-AUC: {roc_auc_score(y_test, rf.predict_proba(X_test)[:,1]):.3f}")

print("\n=== FEATURE IMPORTANCE ===")
importance = pd.Series(rf.feature_importances_, index=features).sort_values(ascending=False)
print(importance)

print("\n=== CLASSIFICATION REPORT (Random Forest) ===")
print(classification_report(y_test, rf_pred))

importance.to_csv("/home/claude/project/outputs/feature_importance.csv")

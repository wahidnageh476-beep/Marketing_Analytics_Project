import pandas as pd

df = pd.read_csv("/home/claude/project/data/marketing_campaign.csv", sep="\t")

print("SHAPE:", df.shape)
print("\nCOLUMNS:", list(df.columns))
print("\nMISSING VALUES:\n", df.isnull().sum()[df.isnull().sum() > 0])
print("\nEducation values:", df["Education"].unique())
print("Marital_Status values:", df["Marital_Status"].unique())
print("\nYear_Birth range:", df["Year_Birth"].min(), "-", df["Year_Birth"].max())
print("Income describe:\n", df["Income"].describe())
print("\nResponse rate (last campaign):", df["Response"].mean())
print("AcceptedCmp1-5 rates:")
for c in ["AcceptedCmp1","AcceptedCmp2","AcceptedCmp3","AcceptedCmp4","AcceptedCmp5"]:
    print(f"  {c}: {df[c].mean():.3f}")
print("\nComplain rate:", df["Complain"].mean())
print("\nDt_Customer sample:", df["Dt_Customer"].head(3).tolist())

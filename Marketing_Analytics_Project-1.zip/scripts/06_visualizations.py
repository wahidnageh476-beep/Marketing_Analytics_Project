import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams["figure.facecolor"] = "white"
NAVY = "#0B2545"
GOLD = "#C9A227"

df = pd.read_csv("/home/claude/project/data/marketing_campaign_with_segments.csv")

# 1. Response rate by income segment
fig, ax = plt.subplots(figsize=(7,4.5))
order = ["Low","Mid-Low","Mid-High","High"]
data = df.groupby("Income_Segment", observed=True)["Response"].mean().reindex(order)
ax.bar(data.index, data.values*100, color=NAVY)
ax.set_ylabel("Response Rate (%)")
ax.set_title("Campaign Response Rate by Income Segment", fontsize=13, fontweight="bold", color=NAVY)
for i,v in enumerate(data.values*100):
    ax.text(i, v+0.5, f"{v:.1f}%", ha="center", fontweight="bold")
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/01_response_by_income.png", dpi=150)
plt.close()

# 2. Response rate by number of children
fig, ax = plt.subplots(figsize=(7,4.5))
data = df.groupby("Total_Children")["Response"].mean()
ax.bar(data.index.astype(str), data.values*100, color=GOLD)
ax.set_xlabel("Number of Children at Home")
ax.set_ylabel("Response Rate (%)")
ax.set_title("Campaign Response Rate by Household Children", fontsize=13, fontweight="bold", color=NAVY)
for i,v in enumerate(data.values*100):
    ax.text(i, v+0.5, f"{v:.1f}%", ha="center", fontweight="bold")
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/02_response_by_children.png", dpi=150)
plt.close()

# 3. Customer segments (RFM) - pie/bar
fig, ax = plt.subplots(figsize=(7,4.5))
order_seg = ["Champions","Loyal Customers","Potential Loyalists","At Risk","Hibernating"]
counts = df["Segment"].value_counts().reindex(order_seg)
colors = [NAVY, "#1B4571", "#8B9DAF", GOLD, "#D9C68A"]
ax.barh(counts.index[::-1], counts.values[::-1], color=colors[::-1])
ax.set_xlabel("Number of Customers")
ax.set_title("Customer Segments (RFM Analysis)", fontsize=13, fontweight="bold", color=NAVY)
for i,v in enumerate(counts.values[::-1]):
    ax.text(v+10, i, str(v), va="center", fontweight="bold")
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/03_rfm_segments.png", dpi=150)
plt.close()

# 4. Campaign acceptance rates (all 6 campaigns)
fig, ax = plt.subplots(figsize=(7,4.5))
camps = ["AcceptedCmp1","AcceptedCmp2","AcceptedCmp3","AcceptedCmp4","AcceptedCmp5","Response"]
labels = ["Campaign 1","Campaign 2","Campaign 3","Campaign 4","Campaign 5","Last Campaign"]
vals = [df[c].mean()*100 for c in camps]
ax.bar(labels, vals, color=NAVY)
ax.set_ylabel("Acceptance Rate (%)")
ax.set_title("Acceptance Rate per Marketing Campaign", fontsize=13, fontweight="bold", color=NAVY)
plt.xticks(rotation=20)
for i,v in enumerate(vals):
    ax.text(i, v+0.3, f"{v:.1f}%", ha="center", fontweight="bold")
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/04_campaign_acceptance.png", dpi=150)
plt.close()

# 5. Spend by product category
fig, ax = plt.subplots(figsize=(7,4.5))
spend_cols = ["MntWines","MntFruits","MntMeatProducts","MntFishProducts","MntSweetProducts","MntGoldProds"]
labels = ["Wines","Fruits","Meat","Fish","Sweets","Gold Prods"]
vals = [df[c].mean() for c in spend_cols]
ax.bar(labels, vals, color=GOLD)
ax.set_ylabel("Avg Spend per Customer ($)")
ax.set_title("Average Spend by Product Category", fontsize=13, fontweight="bold", color=NAVY)
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/05_spend_by_category.png", dpi=150)
plt.close()

# 6. Feature importance from model
imp = pd.read_csv("/home/claude/project/outputs/feature_importance.csv", index_col=0).squeeze()
fig, ax = plt.subplots(figsize=(7,5))
imp_sorted = imp.sort_values()
ax.barh(imp_sorted.index, imp_sorted.values, color=NAVY)
ax.set_xlabel("Importance")
ax.set_title("What Drives Campaign Response? (Feature Importance)", fontsize=13, fontweight="bold", color=NAVY)
plt.tight_layout()
plt.savefig("/home/claude/project/visuals/06_feature_importance.png", dpi=150)
plt.close()

print("All 6 charts saved to visuals/")

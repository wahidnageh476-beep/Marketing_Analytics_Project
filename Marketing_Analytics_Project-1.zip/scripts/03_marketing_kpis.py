import pandas as pd

df = pd.read_csv("/home/claude/project/data/marketing_campaign_cleaned.csv")

print("=== RESPONSE RATE BY EDUCATION ===")
print(df.groupby("Education")["Response"].agg(["mean","count"]).sort_values("mean", ascending=False))

print("\n=== RESPONSE RATE BY MARITAL STATUS ===")
print(df.groupby("Marital_Status")["Response"].agg(["mean","count"]).sort_values("mean", ascending=False))

print("\n=== RESPONSE RATE BY AGE GROUP ===")
print(df.groupby("Age_Group")["Response"].agg(["mean","count"]))

print("\n=== RESPONSE RATE BY INCOME SEGMENT ===")
print(df.groupby("Income_Segment")["Response"].agg(["mean","count"]))

print("\n=== RESPONSE RATE BY NUMBER OF CHILDREN ===")
print(df.groupby("Total_Children")["Response"].agg(["mean","count"]))

print("\n=== SPEND: RESPONDERS vs NON-RESPONDERS ===")
print(df.groupby("Response")["Total_Spend"].mean())

print("\n=== EACH CAMPAIGN ACCEPTANCE RATE ===")
for c in ["AcceptedCmp1","AcceptedCmp2","AcceptedCmp3","AcceptedCmp4","AcceptedCmp5","Response"]:
    print(f"  {c}: {df[c].mean():.1%}")

print("\n=== CHANNEL PREFERENCE (avg purchases per channel) ===")
print(df[["NumWebPurchases","NumCatalogPurchases","NumStorePurchases","NumDealsPurchases"]].mean())

print("\n=== CORRELATION: Web visits vs Web purchases vs Response ===")
print(df[["NumWebVisitsMonth","NumWebPurchases","Response"]].corr())

print("\n=== MULTI-BUYER LOYALTY: Total campaigns accepted distribution ===")
print(df["Total_Campaigns_Accepted"].value_counts().sort_index())

print("\n=== COMPLAINERS: response rate vs non-complainers ===")
print(df.groupby("Complain")["Response"].agg(["mean","count"]))

print("\n=== RECENCY IMPACT ON RESPONSE ===")
df["Recency_Group"] = pd.cut(df["Recency"], bins=[-1,25,50,75,100], labels=["0-25d","26-50d","51-75d","76-99d"])
print(df.groupby("Recency_Group")["Response"].agg(["mean","count"]))

print("\n=== KEY BUSINESS KPIs ===")
total = len(df)
print(f"Total customers: {total}")
print(f"Overall last-campaign response rate: {df['Response'].mean():.1%}")
print(f"Average customer spend: ${df['Total_Spend'].mean():.2f}")
print(f"Average income: ${df['Income'].mean():,.0f}")
print(f"% customers who accepted at least 1 of 6 campaigns: {(df['Total_Campaigns_Accepted']>0).mean():.1%}")
print(f"% customers who never responded to any campaign: {(df['Total_Campaigns_Accepted']==0).mean():.1%}")
print(f"Complaint rate: {df['Complain'].mean():.1%}")

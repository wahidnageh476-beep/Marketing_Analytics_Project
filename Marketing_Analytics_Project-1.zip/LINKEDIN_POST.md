LINKEDIN POST DRAFT
===================
(Arabic version — post this as your main text)
-----------------------------------------------

حللت بيانات 2,212 عميل حقيقي عشان أفهم سؤال بسيط: ليه بعض العملاء بيستجيبوا للحملات التسويقية وأغلبهم لأ؟

النتيجة فاجأتني:
72.7% من العملاء ماستجابوش لأي حملة من أصل 6 حملات متتالية.

بس لما بصيت على الأرقام لقيت أنماط واضحة جدًا:
→ العملاء اللي دخلهم مرتفع بيستجيبوا 27% مقابل 10% بس للدخل المتوسط/المنخفض
→ العملاء من غير أطفال بيستجيبوا 26.6% — أكتر من ضعف أي فئة تانية
→ العميل اللي اشترى في آخر 25 يوم بيستجيب 26% مقابل 7% بس لو مامرش عليه أكتر من 75 يوم

يعني ببساطة: مش كل العملاء لازم ياخدوا نفس الرسالة التسويقية، وشركة كانت بتصرف على حملات بمعدل استجابة أقل من 8% كانت ممكن توفر ميزانيتها لو ركزت على الشريحة الصح.

عملت المشروع كامل من الصفر:
🔹 تنظيف بيانات وFeature Engineering بـ Python
🔹 تحليل SQL لأهم مؤشرات الأداء التسويقية
🔹 تقسيم العملاء (RFM Segmentation) لـ 5 فئات من "Champions" لـ "Hibernating"
🔹 موديل Machine Learning (Random Forest) للتنبؤ باستجابة العميل — وصل لـ ROC-AUC 0.847

المشروع الكامل بالكود والتحليل والداشبورد على GitHub: [ضيف اللينك هنا]

#DataAnalytics #DigitalMarketing #Python #SQL #PowerBI #MarketingAnalytics #DataScience


-----------------------------------------------
(English version — optional, for international reach)
-----------------------------------------------

I analyzed 2,212 real customer records to answer one question: why do most customers ignore marketing campaigns?

The answer: 72.7% of customers never responded to a single campaign across 6 attempts.

But the data revealed clear patterns:
→ High-income customers respond at 27% vs. just 10% for mid/low income
→ Childless households respond at 26.6% — more than double any other segment
→ Customers active in the last 25 days respond at 26% vs. only 7% after 75+ days of inactivity

The takeaway: not every customer deserves the same message, and a campaign converting under 8% is often a targeting problem, not a product problem.

What I built:
🔹 Data cleaning & feature engineering (Python)
🔹 SQL-based marketing KPI analysis
🔹 RFM customer segmentation (5 segments, from "Champions" to "Hibernating")
🔹 A Random Forest model predicting campaign response (ROC-AUC: 0.847)

Full project (code, analysis, dashboard) on GitHub: [add your link]

#DataAnalytics #DigitalMarketing #Python #SQL #PowerBI #MarketingAnalytics #DataScience

-----------------------------------------------
TIPS BEFORE POSTING
-----------------------------------------------
1. Attach 2-3 of the charts from the visuals/ folder as images in the post (carousel format gets more engagement than text-only).
2. Post the GitHub link in the first comment, not the post body — LinkedIn's algorithm favors posts without external links.
3. Best posting time: Tuesday-Thursday, 9-11 AM your timezone.
4. Reply to every comment in the first hour — this boosts reach significantly.
